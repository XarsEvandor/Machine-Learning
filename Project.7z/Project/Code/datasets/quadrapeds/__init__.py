from .animals import CQuadrapedsDataSet
